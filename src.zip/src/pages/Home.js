import React from 'react';

const Home = () =>{
    return(
        <div style={{ textAlign: 'center', padding: '2rem' }}>
      <h1>Home Page</h1>
      </div>
    )
}

export default Home;